<?php
// SCANNER

require 'auth/conn/acc.php';

$type = 'scanner';

$sql = "INSERT INTO action (type)
VALUES ('".$type."')";

$result = mysqli_query($conn,$sql);
$conn->close();

 ?>

<!DOCTYPE html>
<html lang="it">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NECSTCamp | Grazie</title>
  <link rel="icon" href="">
  <meta name="description" content="">
  <meta name="keywords" content="NECST CAMP">
  <meta name="author" content="Team nUx">

    <!-- main css -->
    <link href="css/style.css" rel="stylesheet">

    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <!-- GOOGLE MATERIAL DESIGN LITE -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
    <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>

</head>

<body>

<!-- MENU -->
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
  <header class="mdl-layout__header">
    <div class="mdl-layout__header-row">
      <!--
      <span class="mdl-layout-title">NECSTcamp</span>

      <div class="mdl-layout-spacer"></div>

      <nav class="mdl-navigation mdl-layout--large-screen-only">
        <a class="mdl-navigation__link" href="auth/login.html">Accedi</a>
        <a class="mdl-navigation__link" href="auth/register.html">Registrati</a>
        <a class="mdl-navigation__link" href="info.html">Scopri il NECST camp</a>
      </nav>
    -->
    </div>
  </header>
  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title">NECSTCamp</span>

    <nav class="mdl-navigation">
      <a class="mdl-navigation__link" href="auth/login.html">Accedi</a>
      <a class="mdl-navigation__link" href="auth/register.html">Registrati</a>
      <a class="mdl-navigation__link" href="info.html">Scopri il NECSTCamp!</a>
    </nav>
  </div>
</div>
<br><br><br><br><br>
    <div class="container">
      <!-- TITLE -->
      <h1>NECSTCamp</h1>

      <!-- DESCRIPTION -->
      <p><strong>Grazie!</strong> Hai appena contribuito alla crescita del NECSTCamp</p>

      <!-- Scopri cos'è il NECSTcamp -->
      <a href="info.html">
        <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
          Scopri cos'è il NECSTCamp
        </button>
     </a>

     <br><br>
      <!-- Accedi Registrati -->
      <a href="auth/login.html">
        <button class="mdl-button mdl-js-button mdl-button--primary">
          Accedi
        </button>
     </a>
      <!-- Accedi Registrati -->
      <a href="auth/register.html">
        <button class="mdl-button mdl-js-button mdl-button--primary">
          Registrati
        </button>
     </a>
    </div>

</body>
</html>
