<?php
// REGISTRATION 0.001

// VARS
$name = $_POST['name'];
$surname = $_POST['surname'];
$email = $_POST['email'];
$pass = md5($_POST['pass']);


require 'conn/acc.php';

$sql = "INSERT INTO usr (name, surname, email, pass)
VALUES ('".$name."','".$surname."','".$email."','".$pass."')";
$result = mysqli_query($conn,$sql);

// RE-LOAD THE INFORMATION FOR THE LOGIN
$sql2 = "SELECT * FROM usr WHERE name='".$name."' AND pass='".$pass."'";
echo $sql2;

while($row2= mysqli_fetch_assoc($result2)) {
        $id = $row2['id'];
}


session_start();
$_SESSION['id'] = $id;
header("Location: ../app/home.php");

$conn->close();

?>
