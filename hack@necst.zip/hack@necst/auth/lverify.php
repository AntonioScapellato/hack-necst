<?php

    // LOGIN 0.001

    // VARS
    $name = $_POST['name'];
    $pass = md5($_POST['pass']);


    require 'conn/acc.php';

    $sql = "SELECT * FROM usr WHERE name='".$name."' AND pass='".$pass."'";
    echo $sql;
    $result = mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($result)) {
            $id = $row['id'];
    }

    if(mysqli_num_rows($result) > 0)
    {
      echo "Login sucessfully";

      // SESSION START AFTER A GOOD LOGIN
      session_start();
      $_SESSION['id'] = $id;

      header("Location: ../app/home.php");

    } else {
        echo "NO results";
        header("Location: login.html");
    }

    $conn->close();


?>
