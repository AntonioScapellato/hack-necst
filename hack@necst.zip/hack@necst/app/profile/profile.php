<?php
  //SESSION
  session_start();
  $id = $_SESSION['id'];
  $name = $_SESSION['name'];

?>
<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NECSTCamp | Home.</title>
  <link rel="icon" href="">
  <meta name="description" content="">
  <meta name="keywords" content="NECSTCamp">
  <meta name="author" content="Team nUx">

    <!-- main css -->
    <link href="../../css/style.css" rel="stylesheet">

    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <!-- GOOGLE MATERIAL DESIGN LITE -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
    <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>

</head>

<body>

<!-- MENU -->
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
  <header class="mdl-layout__header">
    <div class="mdl-layout__header-row">
    </div>
  </header>
  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title">NECSTcamp</span>
    <nav class="mdl-navigation">
      <a class="mdl-navigation__link" href="../home.php">Home</a>
      <a class="mdl-navigation__link" href="../profile/profile.php">Profilo</a>
      <a class="mdl-navigation__link" href="../news/news.php">News</a>
      <a class="mdl-navigation__link" href="../community/community.php">Community</a>
      <a class="mdl-navigation__link" href="../../auth/conn/close.php">Esci</a>
    </nav>
  </div>
</div>
<br><br><br>
    <!-- LEGGI -->
    <div class="container">

      <img src="user.png" alt="Nome Cognome" height="42" width="42"><h4><strong>Marco Rossi</h4>
      <p>Interessi</p>
      <!-- Basic Chip -->
      <span class="mdl-chip">
          <span class="mdl-chip__text">Crossfit</span>
      </span>
      <span class="mdl-chip">
          <span class="mdl-chip__text">Nutrizione</span>
      </span>
      <br><br>
      <a href="#">Aggiorna i tuoi dati</a>

      <h4>Ecco i tuoi progressi!</h4>
      <!--I TUOI PROGRESSI-->
      <strong><strong>Esperienza V0</strong>
      <div class="container">
        <input class="mdl-slider mdl-js-slider" type="range"
          min="0" max="100" value="45" tabindex="0" readonly>
      </div>

    </div>

</body>
</html>
