<?php
  // SESSION
  session_start();
  $id = $_SESSION['id'];
?>
<html lang="it">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NECSTCamp | Home.</title>
  <link rel="icon" href="">
  <meta name="description" content="">
  <meta name="keywords" content="NECSTCamp">
  <meta name="author" content="Team nUx">

    <!-- main css & JS-->
    <link href="../css/style.css" rel="stylesheet">
    <link href="../TREE/css/style.css" rel="stylesheet">

    <!-- MODIFICARE IN MODO DINAMICO L'ALBERO -->
    <script src="../TREE/css/script.js"></script>


    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <!-- GOOGLE MATERIAL DESIGN LITE -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
    <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>

</head>
<body>

<!-- MENU -->
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
  <header class="mdl-layout__header">
    <div class="mdl-layout__header-row">

    </div>
  </header>
  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title">NECSTCamp</span>
    <nav class="mdl-navigation">
      <a class="mdl-navigation__link" href="#"><?php echo $name;?></a>
      <a class="mdl-navigation__link" href="profile/profile.php">Profilo</a>
      <a class="mdl-navigation__link" href="news/news.php">News</a>
      <a class="mdl-navigation__link" href="community/community.php">Community</a>
      <a class="mdl-navigation__link" href="../auth/conn/close.php">Esci</a>
      <a class="mdl-navigation__link" href="ar.php" target="_blank"><i class="fa fa-camera"></i> (AR)</a>

    </nav>
  </div>
</div>
<br><br><br>
    <div class="container">
      <!-- TITLE -->
      <h4>Benvenuto nella famiglia del NECSTCamp!</h4>

      <a href="ar.php" target="_blank">
        <button class="mdl-button mdl-js-button mdl-button--primary">
          <i class="fa fa-camera"></i> - Visualizza in AR
        </button>
     </a>
      <br><br>
      <p style="line-height: 1.3; text-align:left;">L'albero della vita rappresenta la <strong>crescita</strong> e lo <strong>sviluppo collettivo potenziale</strong> della nostra comunità.</p>
      <p style="line-height: 1.3; text-align:left;"><strong>TUTTI CONTRIBUISCONO ALLA CRESCITA DELLA PIANTA</strong> </p>


      <div class="post">
      <!-- LOADING LAST ACTIONS
       <?php
        require '../auth/conn/acc.php';
        $sql = "SELECT * FROM `action` ORDER BY `id` DESC LIMIT 4";
        $result = mysqli_query($conn,$sql);
        while($row = mysqli_fetch_array($result)) {

                  $id_usr = $row['id_usr'];
                  //RETRIVE USR INFORMATION
                  $sql2 = "SELECT * FROM usr WHERE id='".$id_usr."'";
                  $result2 = mysqli_query($conn,$sql2);
                  while($row2 = mysqli_fetch_assoc($result2)) {
                          $name = $row2['name'];
                  }

                  // CREATE THE Message
                  if($row['type'] == 'share') {
                    $message = $name." ha condiviso i propri progressi";
                  }
                  if($row['type'] == 'action') {
                    $message = $name." parteciperà ad un evento";
                  }

                  echo  '<p>'.$message.'</p></br>';
           }
           $conn->close();
       ?>-->
       Da qui è possibile visualizzare le ultime azioni della community
      <br><br>
    </div>

    </div>
</body>
</html>
