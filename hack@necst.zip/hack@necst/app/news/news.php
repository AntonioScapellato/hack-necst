<?php
  //SESSION
  session_start();
  $id = $_SESSION['id'];
?>
<!DOCTYPE html>
<html lang="it">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NECSTCamp | News.</title>
  <link rel="icon" href="">
  <meta name="description" content="">
  <meta name="keywords" content="NECSTCamp">
  <meta name="author" content="Team nUx">

    <!-- main css -->
    <link href="../../css/style.css" rel="stylesheet">

    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <!-- GOOGLE MATERIAL DESIGN LITE -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
    <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>

</head>
<body>

<!-- MENU -->
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
  <header class="mdl-layout__header">
    <div class="mdl-layout__header-row">
    </div>
  </header>
  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title">NECSTCamp</span>
    <nav class="mdl-navigation">
      <a class="mdl-navigation__link" href="../home.php">Home</a>
      <a class="mdl-navigation__link" href="../profile/profile.php">Profilo</a>
      <a class="mdl-navigation__link" href="../news/news.php">News</a>
      <a class="mdl-navigation__link" href="../community/community.php">Community</a>
      <a class="mdl-navigation__link" href="../../auth/conn/close.php">Esci</a>
    </nav>
  </div>
</div>
<br><br><br>
    <!-- POST -->
    <form action="action_save.php" method="get">
    <div class="post">
      <h4>12.11.19 <strong>Conferenza nutrizione</strong></h4>
      <h4>Erika Dolcemascolo</h4>
      <p>Presso Sala Seminari DEIB</p>
      <span class="mdl-chip">
          <span class="mdl-chip__text">Nutrizione</span>
      </span>
      <!-- invia -->
      <button class="mdl-button mdl-js-button mdl-button--primary" type="submit">
        Partecipa
      </button>
      </div>
    </form>


    <form action="action_save.php" method="get">
    <div class="post">
      <h4>07.11.19 <strong>Allenamento mattutino</strong></h4>
      <h4>Andal High</h4>
      <p>Presso Campo Giurati</p>
      <span class="mdl-chip">
          <span class="mdl-chip__text">Crossfit</span>
      </span>
      <!-- invia -->
      <button class="mdl-button mdl-js-button mdl-button--primary" type="submit">
        Partecipa
      </button>
    </div>
    </form>

</body>
</html>
