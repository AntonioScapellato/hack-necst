<?php
    // SESSION
    session_start();
    $id = $_SESSION['id'];

    $action = "action";

    require '../../auth/conn/acc.php';

    // ADD ACIOTN
    $sql = "INSERT INTO action (type, id_usr)
    VALUES ('".$action."','".$id."')";

    $result = mysqli_query($conn,$sql);

    header("Location: news.php");

    $conn->close();

?>
