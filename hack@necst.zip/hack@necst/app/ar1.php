<?php
    // SESSION
    session_start();
    $id = $_SESSION['id'];
    require '../auth/conn/acc.php';

    //BASIC SETTINGS
    //tree
    $tree = "tree";

    //LOADING ALL THE ACTION
    $sql = "SELECT * FROM action";
    $result = mysqli_query($conn,$sql);

    //INDEX THAT WE ACTUALLY USE
    $count = mysqli_num_rows($result);

    $width = ($count/5000) + 0.005;
    $height = $width * 1.1;
?>
<html>
<head>
  <script src="https://aframe.io/releases/0.6.0/aframe.min.js"></script>
  <script src="https://jeromeetienne.github.io/AR.js/aframe/build/aframe-ar.js"></script>

</head>
<body style='margin : 0px; overflow: hidden;'>
  <a-scene embedded arjs='sourceType: webcam;' fog="type: linear; color:#AAA" loading-screen="dotsColor: red; backgroundColor: black">


         <!-- ASSETS -->
         <a-assets>

           <!-- TREE -->
          <a-asset-item id="tree-obj" src="tree/3D/<?php echo $tree;?>.obj"></a-asset-item>
          <a-asset-item id="tree-mtl" src="tree/3D/<?php echo $tree;?>.mtl"></a-asset-item>

          <!-- BRANCH-->
          <a-asset-item id="branch-obj" src="tree/3D/branch.obj"></a-asset-item>
          <a-asset-item id="branch-mtl" src="tree/3D/branch.mtl"></a-asset-item>

          <!-- MEX -->
         <a-asset-item id="mex-obj" src="tree/3D/mex.obj"></a-asset-item>
         <a-asset-item id="mex-mtl" src="tree/3D/mex.mtl"></a-asset-item>

         <!-- LEAF -->
         <a-asset-item id="leaf-obj" src="tree/3D/leaf.obj"></a-asset-item>
         <a-asset-item id="leaf-mtl" src="tree/3D/leaf.mtl"></a-asset-item>


        </a-assets>


      <a-marker preset="hiro">

                  <!--TREE -->
                  <a-entity obj-model="obj: #tree-obj; mtl: #tree-mtl"
                            scale="<?php echo $width." ".$height." ".$width." "?>"
                            position="0 0 0">
                            <a-animation attribute="rotation"
                                         dur="10000"
                                         to="0 360 0"
                                         repeat="indefinite">
                           </a-animation>
                  </a-entity>


                  <!-- LOADING BRANCH -->
                  <!-- BRANCH 1 -->
                  <a-entity obj-model="obj: #branch-obj; mtl: #branch-mtl"
                            scale="<?php echo $width." ".$height." "?>0.02"
                            position="-0.45 0.6 0">
                  </a-entity>

                  <!-- BRANCH 2 -->
                  <a-entity obj-model="obj: #branch-obj; mtl: #branch-mtl"
                            scale="<?php echo $width." ".$height." "?>0.02"
                            position="0.45 0.8 0"
                            rotation="0 180 0">
                  </a-entity>

                  <!-- DEMO MESSAGES -->
                  <a-text value="Silvia, Welcome in NECSTCamp!" color="white" scale="0.35 0.35 0" position="-0.3 0.7 -1"></a-text>
                  <a-text value="Antonio has shared his progress" color="white" scale="0.35 0.35 0" position="-0.3 0.6 -1"></a-text>

                  <!-- MEX -->
                  <a-entity obj-model="obj: #mex-obj; mtl: #mex-mtl"
                            scale="0.01 0.01 0.01"
                            position="0.4 -0.1 -1.1">
                  </a-entity>

                  <!-- LOADING THE LAST ACTIONs
                  <a-text value="Ultime news dalla community" color="white" scale="0.35 0.35 0" position="-0.1 0.4 -1"></a-text>
                   <?php
                    require '../auth/conn/acc.php';
                    $sql = "SELECT * FROM `action` ORDER BY `id` DESC LIMIT 3";
                    $result = mysqli_query($conn,$sql);
                    $count = 3;
                    while($row = mysqli_fetch_array($result)) {
                              $id_usr = $row['id_usr'];

                              //RETRIVE USR INFORMATION
                              $sql2 = "SELECT * FROM usr WHERE id='".$id_usr."'";
                              $result2 = mysqli_query($conn,$sql2);
                              while($row2 = mysqli_fetch_assoc($result2)) {
                                      $name = $row2['name'];
                              }

                              // MESSAGE BY TYPE
                              if($row['type'] == 'share') {
                                $message = $name." ha condiviso i propri progressi";
                              }
                              if($row['type'] == 'action') {
                                $message = $name." parteciperà ad un evento";
                              }

                              echo  '
                                          <a-text value="'.$message.'" color="white" scale="0.35 0.35 0" position="-0.1 0.'.($count+0.2).' -1"></a-text>
                                     ';

                              $count--;
                       }
                       $conn->close();
                   ?>-->
                   <a-text value="The year has just begun and the community is starting to shape the tree" color="white" position="-0.7 0.4 0.2" scale="0.35 0.35 0" ></a-text>

  	</a-marker>

  <!-- CAMERA -->
  <a-entity camera></a-entity>
</a-scene>
</body>

<!-- NEXT SCENE-->
<script type="text/javascript">
   setTimeout(function(){
       window.location.replace("http://www.opengraphs.org/app/ar2.php");
   },20000);
</script>
</html>
