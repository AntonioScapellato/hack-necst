<?php
    // SESSION
    session_start();
    $id = $_SESSION['id'];
    require '../auth/conn/acc.php';

    //BASIC SETTINGS
    //tree
    $tree = "tree";

    //LOADING ALL THE ACTION
    $sql = "SELECT * FROM action";
    $result = mysqli_query($conn,$sql);

    //INDEX THAT WE ACTUALLY USE
    $count = mysqli_num_rows($result);

    $width = ($count/5000) + 0.005;
    $height = $width * 1.1;
?>
<html>
<head>
  <script src="https://aframe.io/releases/0.6.0/aframe.min.js"></script>
  <script src="https://jeromeetienne.github.io/AR.js/aframe/build/aframe-ar.js"></script>

</head>
<body style='margin : 0px; overflow: hidden;'>
  <a-scene embedded arjs='sourceType: webcam;' fog="type: linear; color:#AAA" loading-screen="dotsColor: red; backgroundColor: black">


         <!-- ASSETS -->
         <a-assets>

           <!-- TREE -->
          <a-asset-item id="tree-obj" src="tree/3D/<?php echo $tree;?>.obj"></a-asset-item>
          <a-asset-item id="tree-mtl" src="tree/3D/<?php echo $tree;?>.mtl"></a-asset-item>

          <!-- BRANCH-->
          <a-asset-item id="branch-obj" src="tree/3D/branch.obj"></a-asset-item>
          <a-asset-item id="branch-mtl" src="tree/3D/branch.mtl"></a-asset-item>

          <!-- MEX -->
         <a-asset-item id="mex-obj" src="tree/3D/mex.obj"></a-asset-item>
         <a-asset-item id="mex-mtl" src="tree/3D/mex.mtl"></a-asset-item>

         <!-- LEAF -->
        <a-asset-item id="leaf-obj" src="tree/3D/leaf.obj"></a-asset-item>
        <a-asset-item id="leaf-mtl" src="tree/3D/leaf.mtl"></a-asset-item>


        </a-assets>

  <a-marker preset="hiro">

              <!--TREE -->
              <a-entity obj-model="obj: #tree-obj; mtl: #tree-mtl"
                        scale="<?php echo $width." ".$height." ".$width." "?>"
                        position="0 0 0">
                        <a-animation attribute="rotation"
                                     dur="10000"
                                     to="0 360 0"
                                     repeat="indefinite">
                       </a-animation>
              </a-entity>


              <!-- LOADING BRANCH -->

              <!-- TO AUTOMATE -->
              <!-- IDEA Increment and moving in 4 standard directions)

              <!-- LEVEL 1 -->
              <!-- BRANCH 1 -->
              <a-entity obj-model="obj: #branch-obj; mtl: #branch-mtl"
                        scale="<?php echo $width." ".$height." "?>0.02"
                        position="-0.45 0.6 0">
              </a-entity>

              <!-- BRANCH 2 -->
              <a-entity obj-model="obj: #branch-obj; mtl: #branch-mtl"
                        scale="<?php echo $width." ".$height." "?>0.02"
                        position="0.45 0.8 0"
                        rotation="0 180 0">
              </a-entity>

              <!-- LEVEL 2 -->
              <!-- BRANCH 3 -->
              <a-entity obj-model="obj: #branch-obj; mtl: #branch-mtl"
                        scale="<?php echo ($width/2)." ".($height/2)." "?>0.02"
                        position="-0.2 1 0">
              </a-entity>

              <!-- LEVEL 3 -->
              <!-- BRANCH 4 -->
              <a-entity obj-model="obj: #branch-obj; mtl: #branch-mtl"
                        scale="<?php echo ($width/4)." ".($height/4)." "?>0.02"
                        position="0 1.2 -0.1"
                        rotation="0 270 0">
              </a-entity>

              <!-- BRANCH 5 -->
              <a-entity obj-model="obj: #branch-obj; mtl: #branch-mtl"
                        scale="<?php echo ($width/4)." ".($height/4)." "?>0.02"
                        position="0 1.2 0.1"
                        rotation="0 90 0">
              </a-entity>



              <!-- LOADING LEAF-->

              <?php

              //COLORS
              $colors = array("yellow","green", "brown", "yellow","red");

              //FIRST LEAF ALGORITHM
                for($i=1;$i<4;$i++){

                  //CALCULATE POSITION
                  $x = -($i/10)+(-0.45);
                  $y = 0.7+($i/10);

                  echo '
                        <a-sphere color="'.$colors[$i].'" radius="0.05"
                                  position="'.$x.' '.$y.' 0.1">
                        </a-sphere>
                  ';
                }

                for($i=1;$i<4;$i++){

                  //CALCULATE POSITION
                  $x = ($i/10)+(0.45);
                  $y = 0.9+($i/10);

                  echo '
                        <a-sphere color="'.$colors[$i].'" radius="0.05"
                                  position="'.$x.' '.$y.' 0.1">
                        </a-sphere>
                  ';
                }


                for($i=1;$i<4;$i++){

                  //CALCULATE POSITION
                  $x = -($i/10)+(-0.45);
                  $y = 1.1+($i/10);

                  echo '
                        <a-sphere color="'.$colors[$i].'" radius="0.05"
                                  position="'.$x.' '.$y.' 0.1">
                        </a-sphere>
                  ';
                }

                for($i=1;$i<4;$i++){

                  //CALCULATE POSITION
                  $y = 1.25+($i/8);
                  $z = 0.3+($i/8);

                  echo '
                        <a-sphere color="'.$colors[$i].'" radius="0.05"
                                  position="0 '.$y.' '.$z.'">
                        </a-sphere>
                  ';
                }

                for($i=1;$i<4;$i++){

                  //CALCULATE POSITION
                  $y = 1.25+($i/8);
                  $z = -0.3+(-($i/8));

                  echo '
                        <a-sphere color="'.$colors[$i].'" radius="0.05"
                                  position="0 '.$y.' '.$z.'">
                        </a-sphere>
                  ';
                }

              ?>

              <!-- MEX -->
              <a-entity obj-model="obj: #mex-obj; mtl: #mex-mtl"
                        scale="0.5 0.5 0.5"
                        position="0.4 0.2 0.1">
              </a-entity>


              <!-- leaf -->
              <a-entity obj-model="obj: #leaf-obj; mtl: #leaf-mtl"
                        scale="0.5 0.5 0.5"
                        position="0.4 0.2 0.1">
              </a-entity>


              <!-- LOADING THE LAST ACTIONs -->
              <a-text value="Ultime news dalla community" color="white" scale="0.35 0.35 0" position="-0.1 0.4 -1"></a-text>
               <?php
                require '../auth/conn/acc.php';
                $sql = "SELECT * FROM `action` ORDER BY `id` DESC LIMIT 3";
                $result = mysqli_query($conn,$sql);
                $count = 3;
                while($row = mysqli_fetch_array($result)) {
                          $id_usr = $row['id_usr'];

                          //RETRIVE USR INFORMATION
                          $sql2 = "SELECT * FROM usr WHERE id='".$id_usr."'";
                          $result2 = mysqli_query($conn,$sql2);
                          while($row2 = mysqli_fetch_assoc($result2)) {
                                  $name = $row2['name'];
                          }

                          // MESSAGE BY TYPE
                          if($row['type'] == 'share') {
                            $message = $name." ha condiviso i propri progressi";
                          }
                          if($row['type'] == 'action') {
                            $message = $name." parteciperà ad un evento";
                          }

                          echo  '
                                      <a-text value="'.$message.'" color="white" scale="0.35 0.35 0" position="-0.1 0.'.($count+0.2).' -1"></a-text>
                                 ';

                          $count--;
                   }
                   $conn->close();
               ?>
               </a-box>
               <!-- FINAL MESSAGE -->
               <a-text value="Complimenti! Ecco i risultati che avete ottenuto quest'anno!" color="white" position="-0.7 0.4 0.2" scale="0.35 0.35 0" ></a-text>

  	</a-marker>

    <!-- CAMERA -->
  	<a-entity camera></a-entity>
</a-scene>
</body>
</html>
