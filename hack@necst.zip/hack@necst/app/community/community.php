<?php
  //SESSION
  session_start();
  $id = $_SESSION['id'];
?>
<!DOCTYPE html>
<html lang="it">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NECSTCamp | Home.</title>
  <link rel="icon" href="">
  <meta name="description" content="">
  <meta name="keywords" content="NECSTCamp">
  <meta name="author" content="Team nUx">

    <!-- main css -->
    <link href="../../css/style.css" rel="stylesheet">

    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



    <!-- GOOGLE MATERIAL DESIGN LITE -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
    <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>

</head>
<?php
  //SESSION
  session_start();
  $name = $_SESSION['name'];

?>
<body>

<!-- MENU -->
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
  <header class="mdl-layout__header">
    <div class="mdl-layout__header-row">
    </div>
  </header>
  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title">NECSTcamp</span>
    <nav class="mdl-navigation">
      <a class="mdl-navigation__link" href="../home.php">Home</a>
      <a class="mdl-navigation__link" href="../profile/profile.php">Profilo</a>
      <a class="mdl-navigation__link" href="../news/news.php">News</a>
      <a class="mdl-navigation__link" href="../community/community.php">Community</a>
      <a class="mdl-navigation__link" href="../../auth/conn/close.php">Esci</a>
    </nav>
  </div>
</div>
<br><br><br>
<!-- CONDIVIDI I TUOI PROGRESSI -->
<div class="container">
  <!-- TITLE -->
  <h4>Condividi i tuoi progressi</h4>

  <form action="post_save.php" method="get">
  <!-- Floating Multiline Textfield -->
  <div class="mdl-textfield mdl-js-textfield">
    <textarea class="mdl-textfield__input" type="text" rows= "3" id="sample5" ></textarea>
    <label class="mdl-textfield__label" for="sample5">Non essere timido! ...</label>
  </div>
  <!-- invia -->
  <button class="mdl-button mdl-js-button mdl-button--primary">
    invia
  </button>
</form>
</div>
    <!-- POST -->
    <div class="container">
      <!-- TITLE -->
      <h4>Leggi dalla community</h4>
      <div class="post">
        <strong>Maria Francesca</strong><p>Finalmente noto i primi progressi!</p>
        <a href="#">
          <i class="fa fa-heart"></i> 20
        </a>
      </div>
      <div class="post">
        <strong>Marco Antonio</strong><p>Grazie al NECSTCamp nuova dieta e nuove abitudini</p>
        <a href="#">
          <i class="fa fa-heart"></i> 10
        </a>
      </div>
      <div class="post">
        <strong>Mario Rossi</strong><p>Ciao a tutti! Sono nuovo e spero di migliorare me stesso!</p>
        <a href="#">
          <i class="fa fa-heart"></i> 15
        </a>
      </div>
    </div>

</body>
</html>
