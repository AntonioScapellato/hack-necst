<?php
    // SESSION
    session_start();
    $id = $_SESSION['id'];

    $action = "share";

    require '../../auth/conn/acc.php';


    // SAVE ACIOTN
    $sql = "INSERT INTO action (type, id_usr)
    VALUES ('".$action."','".$id."')";
    $result = mysqli_query($conn,$sql);

    echo $action;
    echo $id;
    header("Location: community.php");

    $conn->close();

?>
